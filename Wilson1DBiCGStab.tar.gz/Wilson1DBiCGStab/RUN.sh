#!/bin/sh

./wilson_1d_bicgstab > bicgstab.dat
./wilson_1d_cgne     > cgne.dat
./wilson_1d_cg_fail  > cg_fail.dat
