#!/bin/sh
#
# convert eps files to png files
#

for f in *.eps
do
  pf=${f//eps/png}
  echo $f " => " $pf
  convert -density 200x200 $f $pf
done

