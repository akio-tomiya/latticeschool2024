このファイルは、
格子上の場の理論 夏の学校2024 https://akio-tomiya.github.io/latticeschool2024/
ハンズオンパート2 のファイルです。

kotae_handson_latticeQCDjl_v5-tomiya-exe.pdf　実行結果の見本です。kotae_handson_latticeQCDjl_v5-tomiya-exe.ipynb　実行可能なノートブックです。
my_parameters.toml　パラメータファイルです。

東京女子大学　富谷
akio@yukawa.kyoto-u.ac.jp
2024/09/12